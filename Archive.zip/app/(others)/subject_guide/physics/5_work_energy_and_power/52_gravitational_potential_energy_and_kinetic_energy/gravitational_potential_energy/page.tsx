export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Gravitational Potential Energy</h1>
      <p>This is the page for <strong>5. Work, energy and power → 5.2 Gravitational potential energy and kinetic energy → Gravitational Potential Energy</strong>.</p>
    </div>
  );
}
