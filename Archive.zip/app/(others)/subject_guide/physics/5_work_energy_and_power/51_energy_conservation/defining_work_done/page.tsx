export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Defining Work Done</h1>
      <p>This is the page for <strong>5. Work, energy and power → 5.1 Energy conservation → Defining Work Done</strong>.</p>
    </div>
  );
}
