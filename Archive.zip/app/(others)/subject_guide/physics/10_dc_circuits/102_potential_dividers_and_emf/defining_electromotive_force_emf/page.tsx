export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Defining Electromotive Force (e.m.f.)</h1>
      <p>This is the page for <strong>10. D.C. circuits → 10.2 Potential Dividers and e.m.f. → Defining Electromotive Force (e.m.f.)</strong>.</p>
    </div>
  );
}
