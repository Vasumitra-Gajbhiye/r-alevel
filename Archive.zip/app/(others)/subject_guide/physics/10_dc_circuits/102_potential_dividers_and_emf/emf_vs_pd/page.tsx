export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">e.m.f. vs. p.d.</h1>
      <p>This is the page for <strong>10. D.C. circuits → 10.2 Potential Dividers and e.m.f. → e.m.f. vs. p.d.</strong>.</p>
    </div>
  );
}
