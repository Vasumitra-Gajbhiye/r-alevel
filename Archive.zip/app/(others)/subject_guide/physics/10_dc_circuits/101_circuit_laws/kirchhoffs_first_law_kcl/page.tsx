export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Kirchhoff’s First Law (KCL)</h1>
      <p>This is the page for <strong>10. D.C. circuits → 10.1 Circuit Laws → Kirchhoff’s First Law (KCL)</strong>.</p>
    </div>
  );
}
