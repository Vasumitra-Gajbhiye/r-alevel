export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Exchange Particles</h1>
      <p>This is the page for <strong>11. Particle Physics → 11.2 Fundamental Forces → Exchange Particles</strong>.</p>
    </div>
  );
}
