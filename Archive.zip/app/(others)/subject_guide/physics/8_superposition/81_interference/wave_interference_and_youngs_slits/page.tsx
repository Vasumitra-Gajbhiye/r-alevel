export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Wave Interference and Young’s Slits</h1>
      <p>This is the page for <strong>8. Superposition → 8.1 Interference → Wave Interference and Young’s Slits</strong>.</p>
    </div>
  );
}
