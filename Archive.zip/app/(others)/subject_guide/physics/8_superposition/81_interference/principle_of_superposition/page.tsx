export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Principle of Superposition</h1>
      <p>This is the page for <strong>8. Superposition → 8.1 Interference → Principle of Superposition</strong>.</p>
    </div>
  );
}
