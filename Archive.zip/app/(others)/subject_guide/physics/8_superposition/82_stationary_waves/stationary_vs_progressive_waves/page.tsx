export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Stationary vs. Progressive Waves</h1>
      <p>This is the page for <strong>8. Superposition → 8.2 Stationary Waves → Stationary vs. Progressive Waves</strong>.</p>
    </div>
  );
}
