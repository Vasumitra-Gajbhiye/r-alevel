export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Explaining Resonance</h1>
      <p>This is the page for <strong>17. Oscillations → 17.2 Damping and Resonance → Explaining Resonance</strong>.</p>
    </div>
  );
}
