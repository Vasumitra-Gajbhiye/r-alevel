export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">SHM Defining Equation</h1>
      <p>This is the page for <strong>17. Oscillations → 17.1 Simple Harmonic Motion (SHM) → SHM Defining Equation</strong>.</p>
    </div>
  );
}
