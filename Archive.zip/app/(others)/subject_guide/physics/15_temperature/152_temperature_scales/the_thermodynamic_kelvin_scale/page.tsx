export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">The Thermodynamic (Kelvin) Scale</h1>
      <p>This is the page for <strong>15. Temperature → 15.2 Temperature Scales → The Thermodynamic (Kelvin) Scale</strong>.</p>
    </div>
  );
}
