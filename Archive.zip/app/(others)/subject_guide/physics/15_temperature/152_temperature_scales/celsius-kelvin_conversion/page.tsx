export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Celsius-Kelvin Conversion</h1>
      <p>This is the page for <strong>15. Temperature → 15.2 Temperature Scales → Celsius-Kelvin Conversion</strong>.</p>
    </div>
  );
}
