export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Using the Kelvin Temperature Scale</h1>
      <p>This is the page for <strong>14. Ideal gases → 14.1 The Ideal Gas Equation → Using the Kelvin Temperature Scale</strong>.</p>
    </div>
  );
}
