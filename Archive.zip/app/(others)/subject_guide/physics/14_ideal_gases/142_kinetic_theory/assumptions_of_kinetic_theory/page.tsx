export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Assumptions of Kinetic Theory</h1>
      <p>This is the page for <strong>14. Ideal gases → 14.2 Kinetic Theory → Assumptions of Kinetic Theory</strong>.</p>
    </div>
  );
}
