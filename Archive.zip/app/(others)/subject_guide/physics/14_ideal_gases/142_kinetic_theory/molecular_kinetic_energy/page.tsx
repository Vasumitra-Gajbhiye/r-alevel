export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Molecular Kinetic Energy</h1>
      <p>This is the page for <strong>14. Ideal gases → 14.2 Kinetic Theory → Molecular Kinetic Energy</strong>.</p>
    </div>
  );
}
