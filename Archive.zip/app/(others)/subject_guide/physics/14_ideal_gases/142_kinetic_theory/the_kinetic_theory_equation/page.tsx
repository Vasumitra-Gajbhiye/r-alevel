export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">The Kinetic Theory Equation</h1>
      <p>This is the page for <strong>14. Ideal gases → 14.2 Kinetic Theory → The Kinetic Theory Equation</strong>.</p>
    </div>
  );
}
