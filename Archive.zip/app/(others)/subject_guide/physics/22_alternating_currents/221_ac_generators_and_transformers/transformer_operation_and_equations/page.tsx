export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Transformer Operation and Equations</h1>
      <p>This is the page for <strong>22. Alternating currents → 22.1 A.C. Generators and Transformers → Transformer Operation and Equations</strong>.</p>
    </div>
  );
}
