export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Defining and Using r.m.s. Values</h1>
      <p>This is the page for <strong>22. Alternating currents → 22.1 A.C. Generators and Transformers → Defining and Using r.m.s. Values</strong>.</p>
    </div>
  );
}
