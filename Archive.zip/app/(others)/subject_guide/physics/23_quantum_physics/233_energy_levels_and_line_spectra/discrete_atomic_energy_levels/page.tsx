export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Discrete Atomic Energy Levels</h1>
      <p>This is the page for <strong>23. Quantum physics → 23.3 Energy Levels and Line Spectra → Discrete Atomic Energy Levels</strong>.</p>
    </div>
  );
}
