export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Work Function, Threshold and Photoelectric Equation</h1>
      <p>This is the page for <strong>23. Quantum physics → 23.2 Photoelectric Effect → Work Function, Threshold and Photoelectric Equation</strong>.</p>
    </div>
  );
}
