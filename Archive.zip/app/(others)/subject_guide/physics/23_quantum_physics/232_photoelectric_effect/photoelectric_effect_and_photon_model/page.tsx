export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Photoelectric Effect and Photon Model</h1>
      <p>This is the page for <strong>23. Quantum physics → 23.2 Photoelectric Effect → Photoelectric Effect and Photon Model</strong>.</p>
    </div>
  );
}
