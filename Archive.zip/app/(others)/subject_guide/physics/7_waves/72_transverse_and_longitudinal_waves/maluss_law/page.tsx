export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Malus’s Law</h1>
      <p>This is the page for <strong>7. Waves → 7.2 Transverse and Longitudinal Waves → Malus’s Law</strong>.</p>
    </div>
  );
}
