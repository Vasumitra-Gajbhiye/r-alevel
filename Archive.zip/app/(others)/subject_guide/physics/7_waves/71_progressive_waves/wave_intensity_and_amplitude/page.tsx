export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Wave Intensity and Amplitude</h1>
      <p>This is the page for <strong>7. Waves → 7.1 Progressive Waves → Wave Intensity and Amplitude</strong>.</p>
    </div>
  );
}
