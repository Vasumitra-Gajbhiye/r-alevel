export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Stress, Strain, and Young Modulus</h1>
      <p>This is the page for <strong>6. Deformation of solids → 6.1 Stress and Strain → Stress, Strain, and Young Modulus</strong>.</p>
    </div>
  );
}
