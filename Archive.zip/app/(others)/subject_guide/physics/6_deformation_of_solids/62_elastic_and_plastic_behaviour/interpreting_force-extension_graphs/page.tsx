export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Interpreting Force-Extension Graphs</h1>
      <p>This is the page for <strong>6. Deformation of solids → 6.2 Elastic and Plastic Behaviour → Interpreting Force-Extension Graphs</strong>.</p>
    </div>
  );
}
