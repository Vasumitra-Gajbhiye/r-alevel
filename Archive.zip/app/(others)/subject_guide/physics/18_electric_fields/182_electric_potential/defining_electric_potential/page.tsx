export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Defining Electric Potential</h1>
      <p>This is the page for <strong>18. Electric fields → 18.2 Electric Potential → Defining Electric Potential</strong>.</p>
    </div>
  );
}
