export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Electric Field Concept</h1>
      <p>This is the page for <strong>18. Electric fields → 18.1 Electric Force and Field → Electric Field Concept</strong>.</p>
    </div>
  );
}
