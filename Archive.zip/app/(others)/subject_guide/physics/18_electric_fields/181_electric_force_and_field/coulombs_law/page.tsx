export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Coulomb’s Law</h1>
      <p>This is the page for <strong>18. Electric fields → 18.1 Electric Force and Field → Coulomb’s Law</strong>.</p>
    </div>
  );
}
