export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">X-ray Production and Spectra</h1>
      <p>This is the page for <strong>25. Medical physics → 25.1 X-rays → X-ray Production and Spectra</strong>.</p>
    </div>
  );
}
