export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Ultrasound Imaging and Acoustic Impedance</h1>
      <p>This is the page for <strong>25. Medical physics → 25.2 Ultrasound → Ultrasound Imaging and Acoustic Impedance</strong>.</p>
    </div>
  );
}
