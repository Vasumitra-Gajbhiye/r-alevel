/* eslint-disable react/no-unescaped-entities */
export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Resistance, Ohm's Law</h1>
      <p>This is the page for <strong>9. Electricity → 9.1 Electric Current, Charge, and p.d. → Resistance, Ohm's Law</strong>.</p>
    </div>
  );
}
