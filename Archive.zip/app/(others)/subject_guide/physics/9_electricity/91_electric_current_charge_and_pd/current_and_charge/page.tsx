export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Current and Charge</h1>
      <p>This is the page for <strong>9. Electricity → 9.1 Electric Current, Charge, and p.d. → Current and Charge</strong>.</p>
    </div>
  );
}
