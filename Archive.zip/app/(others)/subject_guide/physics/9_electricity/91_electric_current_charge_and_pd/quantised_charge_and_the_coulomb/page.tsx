export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Quantised Charge and The Coulomb</h1>
      <p>This is the page for <strong>9. Electricity → 9.1 Electric Current, Charge, and p.d. → Quantised Charge and The Coulomb</strong>.</p>
    </div>
  );
}
