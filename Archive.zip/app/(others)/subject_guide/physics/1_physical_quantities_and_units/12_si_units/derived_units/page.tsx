export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Derived Units</h1>
      <p>This is the page for <strong>1. Physical quantities and units → 1.2 SI units → Derived Units</strong>.</p>
    </div>
  );
}
