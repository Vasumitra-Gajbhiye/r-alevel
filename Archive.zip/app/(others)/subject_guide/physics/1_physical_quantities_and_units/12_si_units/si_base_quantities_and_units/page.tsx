export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">SI Base Quantities and Units</h1>
      <p>This is the page for <strong>1. Physical quantities and units → 1.2 SI units → SI Base Quantities and Units</strong>.</p>
    </div>
  );
}
