export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Checking Equation Homogeneity</h1>
      <p>This is the page for <strong>1. Physical quantities and units → 1.2 SI units → Checking Equation Homogeneity</strong>.</p>
    </div>
  );
}
