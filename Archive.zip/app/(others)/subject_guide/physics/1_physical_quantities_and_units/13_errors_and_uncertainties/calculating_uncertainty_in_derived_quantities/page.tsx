export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Calculating Uncertainty in Derived Quantities</h1>
      <p>This is the page for <strong>1. Physical quantities and units → 1.3 Errors and uncertainties → Calculating Uncertainty in Derived Quantities</strong>.</p>
    </div>
  );
}
