export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Vector Components</h1>
      <p>This is the page for <strong>1. Physical quantities and units → 1.4 Scalars and vectors → Vector Components</strong>.</p>
    </div>
  );
}
