export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Adding and Subtracting Vectors</h1>
      <p>This is the page for <strong>1. Physical quantities and units → 1.4 Scalars and vectors → Adding and Subtracting Vectors</strong>.</p>
    </div>
  );
}
