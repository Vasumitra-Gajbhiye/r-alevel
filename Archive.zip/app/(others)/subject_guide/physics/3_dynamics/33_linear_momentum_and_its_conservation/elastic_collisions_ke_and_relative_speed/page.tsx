export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Elastic Collisions: KE and Relative Speed</h1>
      <p>This is the page for <strong>3. Dynamics → 3.3 Linear momentum and its conservation → Elastic Collisions: KE and Relative Speed</strong>.</p>
    </div>
  );
}
