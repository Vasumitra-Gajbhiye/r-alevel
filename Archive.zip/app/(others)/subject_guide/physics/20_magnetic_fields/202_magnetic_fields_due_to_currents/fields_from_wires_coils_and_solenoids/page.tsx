export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Fields from Wires, Coils, and Solenoids</h1>
      <p>This is the page for <strong>20. Magnetic fields → 20.2 Magnetic Fields Due to Currents → Fields from Wires, Coils, and Solenoids</strong>.</p>
    </div>
  );
}
