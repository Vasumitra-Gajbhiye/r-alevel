export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">The Velocity Selector</h1>
      <p>This is the page for <strong>20. Magnetic fields → 20.1 Force on a Moving Charge → The Velocity Selector</strong>.</p>
    </div>
  );
}
