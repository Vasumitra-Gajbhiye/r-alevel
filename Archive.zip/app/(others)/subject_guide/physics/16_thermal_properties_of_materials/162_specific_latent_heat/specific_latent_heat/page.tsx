export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Specific Latent Heat</h1>
      <p>This is the page for <strong>16. Thermal properties of materials → 16.2 Specific Latent Heat → Specific Latent Heat</strong>.</p>
    </div>
  );
}
