export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Displacement from v-t Graph Area</h1>
      <p>This is the page for <strong>2. Kinematics → 2.1 Equations of motion → Displacement from v-t Graph Area</strong>.</p>
    </div>
  );
}
