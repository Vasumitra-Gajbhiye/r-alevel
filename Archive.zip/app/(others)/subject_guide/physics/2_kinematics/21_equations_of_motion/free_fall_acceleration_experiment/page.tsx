export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Free Fall Acceleration Experiment</h1>
      <p>This is the page for <strong>2. Kinematics → 2.1 Equations of motion → Free Fall Acceleration Experiment</strong>.</p>
    </div>
  );
}
