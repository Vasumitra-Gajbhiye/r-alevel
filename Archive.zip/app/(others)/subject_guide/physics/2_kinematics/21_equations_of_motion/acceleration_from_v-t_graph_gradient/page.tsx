export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Acceleration from v-t Graph Gradient</h1>
      <p>This is the page for <strong>2. Kinematics → 2.1 Equations of motion → Acceleration from v-t Graph Gradient</strong>.</p>
    </div>
  );
}
