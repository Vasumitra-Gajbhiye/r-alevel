export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Capacitor Charging and Discharging</h1>
      <p>This is the page for <strong>19. Capacitance → 19.2 Energy and Charging → Capacitor Charging and Discharging</strong>.</p>
    </div>
  );
}
