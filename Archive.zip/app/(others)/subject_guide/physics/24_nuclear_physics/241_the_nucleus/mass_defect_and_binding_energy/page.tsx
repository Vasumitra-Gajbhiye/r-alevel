export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Mass Defect and Binding Energy</h1>
      <p>This is the page for <strong>24. Nuclear physics → 24.1 The Nucleus → Mass Defect and Binding Energy</strong>.</p>
    </div>
  );
}
