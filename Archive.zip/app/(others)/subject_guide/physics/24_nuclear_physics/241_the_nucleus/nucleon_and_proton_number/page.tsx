export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Nucleon and Proton Number</h1>
      <p>This is the page for <strong>24. Nuclear physics → 24.1 The Nucleus → Nucleon and Proton Number</strong>.</p>
    </div>
  );
}
