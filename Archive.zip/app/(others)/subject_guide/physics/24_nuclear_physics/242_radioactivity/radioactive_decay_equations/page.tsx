export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Radioactive Decay Equations</h1>
      <p>This is the page for <strong>24. Nuclear physics → 24.2 Radioactivity → Radioactive Decay Equations</strong>.</p>
    </div>
  );
}
