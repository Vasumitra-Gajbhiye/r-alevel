export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Lenz’s Law</h1>
      <p>This is the page for <strong>21. Electromagnetic induction → 21.2 Faraday’s and Lenz’s Laws → Lenz’s Law</strong>.</p>
    </div>
  );
}
