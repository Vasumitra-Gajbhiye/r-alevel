export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Defining Gravitational Potential</h1>
      <p>This is the page for <strong>13. Gravitational fields → 13.2 Gravitational Potential → Defining Gravitational Potential</strong>.</p>
    </div>
  );
}
