export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Centre of Gravity (CG)</h1>
      <p>This is the page for <strong>4. Forces, density and pressure → 4.1 Turning effects of forces → Centre of Gravity (CG)</strong>.</p>
    </div>
  );
}
