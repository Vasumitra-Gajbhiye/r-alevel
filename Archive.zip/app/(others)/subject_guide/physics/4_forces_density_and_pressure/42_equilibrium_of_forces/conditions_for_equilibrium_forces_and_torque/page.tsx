export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Conditions for Equilibrium (Forces and Torque)</h1>
      <p>This is the page for <strong>4. Forces, density and pressure → 4.2 Equilibrium of forces → Conditions for Equilibrium (Forces and Torque)</strong>.</p>
    </div>
  );
}
