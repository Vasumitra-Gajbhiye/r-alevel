export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Upthrust and Hydrostatic Pressure</h1>
      <p>This is the page for <strong>4. Forces, density and pressure → 4.3 Density and pressure → Upthrust and Hydrostatic Pressure</strong>.</p>
    </div>
  );
}
