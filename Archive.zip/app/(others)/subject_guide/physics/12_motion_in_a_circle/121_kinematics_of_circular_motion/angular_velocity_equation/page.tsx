export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Angular Velocity Equation</h1>
      <p>This is the page for <strong>12. Motion in a circle → 12.1 Kinematics of Circular Motion → Angular Velocity Equation</strong>.</p>
    </div>
  );
}
