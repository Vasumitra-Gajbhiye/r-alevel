export default function Divider() {
  return (
    <div className="my-12">
      <div className="h-px w-full bg-slate-200/60" />
    </div>
  );
}
