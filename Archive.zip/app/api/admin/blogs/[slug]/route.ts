import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { hasAnyRole } from "@/lib/roles";
import connectDB from "@/libs/mongodb";
import EditorBlog from "@/models/editorBlogs";
import { Types } from "mongoose";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";

/* ---------------- GET BLOG ---------------- */
export async function GET(
  req: Request,
  context: { params: Promise<{ slug: string }> }
) {
  await connectDB();

  const session = await getServerSession(authOptions);
  if (!session || !session.userData?.roles?.length) {
    return new Response("Unauthorized", { status: 401 });
  }

  const { slug } = await context.params;
  const isAdminLike = hasAnyRole(session.userData.roles, ["admin", "owner"]);

  const ownerObjectId = new Types.ObjectId(session.userData.id);

  const query = isAdminLike ? { slug } : { slug, ownerId: ownerObjectId };

  const blog = await EditorBlog.findOne(query);

  if (!blog) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json(blog);
}

/* ---------------- UPDATE BLOG ---------------- */
export async function PATCH(
  req: Request,
  context: { params: Promise<{ slug: string }> }
) {
  await connectDB();

  const session = await getServerSession(authOptions);
  if (!session || !session.userData?.roles?.length) {
    return new Response("Unauthorized", { status: 401 });
  }

  const { slug } = await context.params;
  const body = await req.json();

  const isAdminLike = hasAnyRole(session.userData.roles, ["admin", "owner"]);

  const ownerObjectId = new Types.ObjectId(session.userData.id);

  const query = isAdminLike ? { slug } : { slug, ownerId: ownerObjectId };

  const blog = await EditorBlog.findOne(query);

  if (!blog) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  if (typeof body.title === "string") {
    blog.title = body.title;
  }

  if (body.metadata) {
    blog.metadata = body.metadata;
  }

  if (Array.isArray(body.blocks)) {
    blog.blocks = body.blocks;
  }

  await blog.save();

  return NextResponse.json({ success: true });
}

/* ---------------- DELETE BLOG ---------------- */
export async function DELETE(
  req: Request,
  context: { params: Promise<{ slug: string }> }
) {
  await connectDB();

  const session = await getServerSession(authOptions);
  if (!session || !session.userData?.roles?.length) {
    return new Response("Unauthorized", { status: 401 });
  }

  const { slug } = await context.params;
  const isAdminLike = hasAnyRole(session.userData.roles, ["admin", "owner"]);

  const ownerObjectId = new Types.ObjectId(session.userData.id);

  const query = isAdminLike ? { slug } : { slug, ownerId: ownerObjectId };

  await EditorBlog.findOneAndDelete(query);

  return NextResponse.json({ success: true });
}
