import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { slugify } from "@/lib/slugify";
import connectDB from "@/libs/mongodb";
import EditorBlog from "@/models/editorBlogs";
import mongoose, { Types } from "mongoose";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";

export async function GET() {
  await connectDB();

  const session = await getServerSession(authOptions);
  const userData = session?.userData;

  if (!userData || !userData.roles.length) {
    return new Response("Unauthorized", { status: 401 });
  }

  const isAdmin =
    userData.roles.includes("admin") || userData.roles.includes("owner");

  const match = isAdmin ? {} : { ownerId: new Types.ObjectId(userData.id) };

  const blogs = await EditorBlog.aggregate([
    { $match: match },
    {
      $lookup: {
        from: "userdatas",
        localField: "ownerId",
        foreignField: "_id",
        as: "owner",
      },
    },
    { $unwind: "$owner" },
    {
      $project: {
        title: 1,
        slug: 1,
        updatedAt: 1,
        ownerId: 1,
        ownerName: "$owner.name",
        ownerEmail: "$owner.email",
      },
    },
    { $sort: { updatedAt: -1 } },
  ]);

  return NextResponse.json(blogs);
}
/* ---------------- CREATE BLOG ---------------- */

export async function POST() {
  await connectDB();

  const session = await getServerSession(authOptions);
  const userData = session?.userData;

  if (!userData || !userData.roles.length) {
    return new Response("Unauthorized", { status: 401 });
  }

  const blog = await EditorBlog.create({
    ownerId: new mongoose.Types.ObjectId(userData.id),
    title: "Untitled document",
    slug: slugify(`Untitled-${Date.now()}`),
    metadata: {
      title: "New Blog",
      author: session?.user?.name || "",
    },
    blocks: [],
  });

  return NextResponse.json(blog, { status: 201 });
}
