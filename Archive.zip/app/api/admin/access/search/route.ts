import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import connectDB from "@/libs/mongodb";
import UserData from "@/models/userData";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";

/* ---------------- SEARCH USERS BY EMAIL ---------------- */
export async function GET(req: Request) {
  await connectDB();

  const session = await getServerSession(authOptions);
  const roles = session?.userData?.roles;

  // 🔒 Only admin / owner can search
  if (!roles || (!roles.includes("admin") && !roles.includes("owner"))) {
    return new Response("Unauthorized", { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim();

  if (!q || q.length < 2) {
    return NextResponse.json([]);
  }

  const users = await UserData.find({
    email: { $regex: `^${q}`, $options: "i" },
  })
    .limit(5)
    .select("email name")
    .lean();

  return NextResponse.json(users);
}
