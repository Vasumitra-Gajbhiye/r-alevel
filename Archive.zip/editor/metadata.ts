export type BlogMetadata = {
  slug: string;
  title: string;
  author: string;
  date: string;
  tag: string;
  image: string;
};
